Page({
  connectMysql() {
    wx.cloud.callFunction({
      name: "mysql",
      success(res) {
        console.log("成功", res)
      },
      fail(res) {
        console.log("失败", res)
      }
    })
  }
})